export type Client = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address: string;
  taxId?: string;
  history?: string; // e.g. "new client", "pays on time"
};

export type CatalogItem = {
  id: string;
  name: string;
  description: string;
  unitPrice: number;
};

export type LineItem = {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
};

export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue';

export type Invoice = {
  id: string;
  invoiceNumber: string;
  clientId: string;
  date: string;
  dueDate: string;
  items: LineItem[];
  status: InvoiceStatus;
  notes?: string;
  paymentTerms?: string;
  total: number;
};