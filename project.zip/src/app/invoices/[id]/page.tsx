"use client"

import { useBillStreamData } from "@/hooks/use-billstream-data"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, Printer, Send, FileCheck } from "lucide-react"
import { format } from "date-fns"

export default function InvoiceDetailPage() {
  const { id } = useParams()
  const router = useRouter()
  const { invoices, clients } = useBillStreamData()

  const invoice = invoices.find(inv => inv.id === id)
  if (!invoice) return <div className="p-8">Invoice not found.</div>

  const client = clients.find(c => c.id === invoice.clientId)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between no-print">
        <Button variant="ghost" onClick={() => router.back()}>
          <ChevronLeft className="mr-2 h-4 w-4" /> Back to Invoices
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="mr-2 h-4 w-4" /> Print PDF
          </Button>
          <Button className="bg-accent text-accent-foreground">
            <Send className="mr-2 h-4 w-4" /> Send to Client
          </Button>
        </div>
      </div>

      <Card className="bg-white text-slate-900 border-none shadow-xl print:shadow-none print:border-none">
        <CardContent className="p-12">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-100 pb-12 mb-12">
            <div>
              <div className="bg-primary text-white p-2 rounded-lg inline-block mb-4">
                <FileCheck size={32} />
              </div>
              <h1 className="text-4xl font-black tracking-tighter uppercase text-primary">Invoice</h1>
              <p className="text-slate-500 font-medium">#{invoice.invoiceNumber}</p>
            </div>
            <div className="text-right">
              <h2 className="text-2xl font-bold mb-1">BillStream Inc.</h2>
              <p className="text-slate-500 text-sm">123 Business Avenue</p>
              <p className="text-slate-500 text-sm">San Francisco, CA 94105</p>
              <p className="text-slate-500 text-sm">support@billstream.com</p>
            </div>
          </div>

          {/* Billing Info */}
          <div className="grid grid-cols-2 gap-12 mb-12">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Bill To</p>
              <h3 className="text-xl font-bold mb-2">{client?.name || 'Unknown Client'}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{client?.address}</p>
              <p className="text-slate-500 text-sm mt-1">{client?.email}</p>
              {client?.taxId && <p className="text-slate-500 text-xs mt-2 font-mono">Tax ID: {client.taxId}</p>}
            </div>
            <div className="text-right space-y-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Invoice Date</p>
                <p className="font-medium">{format(new Date(invoice.date), 'MMMM dd, yyyy')}</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Due Date</p>
                <p className="font-bold text-accent">{format(new Date(invoice.dueDate), 'MMMM dd, yyyy')}</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Terms</p>
                <p className="font-medium italic">{invoice.paymentTerms || 'Standard'}</p>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="mb-12">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b-2 border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
                  <th className="py-4">Description</th>
                  <th className="py-4 text-center">Qty</th>
                  <th className="py-4 text-right">Unit Price</th>
                  <th className="py-4 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items.map((item) => (
                  <tr key={item.id} className="border-b border-slate-50">
                    <td className="py-6 font-medium">{item.description}</td>
                    <td className="py-6 text-center">{item.quantity}</td>
                    <td className="py-6 text-right">${item.unitPrice.toLocaleString()}</td>
                    <td className="py-6 text-right font-bold">${(item.quantity * item.unitPrice).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer Totals */}
          <div className="flex justify-end mb-12">
            <div className="w-64 space-y-3">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span>${invoice.total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Tax (0%)</span>
                <span>$0.00</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-4 text-2xl font-black text-primary">
                <span>Total</span>
                <span>${invoice.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Notes */}
          {invoice.notes && (
            <div className="p-6 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Notes</p>
              <p className="text-sm text-slate-600 leading-relaxed italic">{invoice.notes}</p>
            </div>
          )}

          <div className="mt-12 pt-12 border-t border-slate-100 text-center">
            <p className="text-slate-400 text-xs">Thank you for your business! Please make payments to the account mentioned above.</p>
          </div>
        </CardContent>
      </Card>

      <style jsx global>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .print\\:shadow-none { box-shadow: none !important; }
          .print\\:border-none { border: none !important; }
        }
      `}</style>
    </div>
  )
}