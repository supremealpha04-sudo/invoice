"use client"

import { useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import { useBillStreamData } from "@/hooks/use-billstream-data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Trash2, Plus, Sparkles, Loader2, Save, X } from "lucide-react"
import { Invoice, LineItem } from "@/lib/types"
import { suggestPaymentTerms } from "@/ai/flows/suggest-payment-terms"
import { useToast } from "@/hooks/use-toast"

export default function NewInvoicePage() {
  const router = useRouter()
  const { toast } = useToast()
  const { clients, catalog, saveInvoice, invoices } = useBillStreamData()
  
  const [selectedClientId, setSelectedClientId] = useState("")
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0])
  const [dueDate, setDueDate] = useState("")
  const [lineItems, setLineItems] = useState<LineItem[]>([
    { id: '1', description: '', quantity: 1, unitPrice: 0 }
  ])
  const [notes, setNotes] = useState("")
  const [paymentTerms, setPaymentTerms] = useState("")
  const [isAiLoading, setIsAiLoading] = useState(false)
  const [aiSuggestions, setAiSuggestions] = useState<{terms: string[], reasoning: string} | null>(null)

  const nextInvoiceNumber = useMemo(() => {
    const last = invoices[invoices.length - 1]
    if (!last) return "INV-1001"
    const num = parseInt(last.invoiceNumber.split('-')[1])
    return `INV-${num + 1}`
  }, [invoices])

  const totalAmount = useMemo(() => {
    return lineItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0)
  }, [lineItems])

  const addLineItem = () => {
    setLineItems([...lineItems, { id: Math.random().toString(), description: '', quantity: 1, unitPrice: 0 }])
  }

  const removeLineItem = (id: string) => {
    if (lineItems.length === 1) return
    setLineItems(lineItems.filter(item => item.id !== id))
  }

  const updateLineItem = (id: string, field: keyof LineItem, value: string | number) => {
    setLineItems(lineItems.map(item => item.id === id ? { ...item, [field]: value } : item))
  }

  const handleSelectCatalogItem = (itemId: string, lineId: string) => {
    const catalogItem = catalog.find(i => i.id === itemId)
    if (!catalogItem) return
    setLineItems(lineItems.map(item => item.id === lineId ? { 
      ...item, 
      description: catalogItem.name, 
      unitPrice: catalogItem.unitPrice 
    } : item))
  }

  const handleAiSuggestTerms = async () => {
    const client = clients.find(c => c.id === selectedClientId)
    if (!client) {
      toast({ title: "Please select a client first", variant: "destructive" })
      return
    }

    setIsAiLoading(true)
    try {
      const result = await suggestPaymentTerms({
        invoiceTotal: totalAmount,
        clientHistory: client.history || "New client",
        businessPractices: "Standard Net 30 for established, upfront for high value/new clients."
      })
      setAiSuggestions({ terms: result.suggestedTerms, reasoning: result.reasoning })
    } catch (e) {
      toast({ title: "AI suggestion failed", variant: "destructive" })
    } finally {
      setIsAiLoading(false)
    }
  }

  const handleSave = (status: 'draft' | 'sent') => {
    if (!selectedClientId) {
      toast({ title: "Please select a client", variant: "destructive" })
      return
    }

    const newInvoice: Invoice = {
      id: Math.random().toString(36).substr(2, 9),
      invoiceNumber: nextInvoiceNumber,
      clientId: selectedClientId,
      date: invoiceDate,
      dueDate: dueDate || invoiceDate,
      items: lineItems,
      status: status,
      notes,
      paymentTerms,
      total: totalAmount,
    }

    saveInvoice(newInvoice)
    toast({ title: `Invoice ${status === 'sent' ? 'sent' : 'saved as draft'}` })
    router.push("/invoices")
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Create New Invoice</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.back()}><X className="mr-2 h-4 w-4" /> Cancel</Button>
          <Button variant="outline" onClick={() => handleSave('draft')}><Save className="mr-2 h-4 w-4" /> Draft</Button>
          <Button className="bg-primary text-primary-foreground" onClick={() => handleSave('sent')}>Save & Send</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Invoice Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Invoice Number</Label>
                <Input value={nextInvoiceNumber} readOnly className="bg-muted font-bold" />
              </div>
              <div className="space-y-2">
                <Label>Client</Label>
                <Select onValueChange={setSelectedClientId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map(client => (
                      <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>
                    ))}
                    {clients.length === 0 && (
                      <div className="p-2 text-xs text-center text-muted-foreground">No clients found</div>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Due Date</Label>
                <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
            </div>

            <div className="space-y-4">
              <Label>Line Items</Label>
              <div className="space-y-3">
                {lineItems.map((item, idx) => (
                  <div key={item.id} className="flex gap-3 items-start border-b pb-4 last:border-0 last:pb-0">
                    <div className="flex-1 space-y-2">
                      <Select onValueChange={(val) => handleSelectCatalogItem(val, item.id)}>
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder="Select from catalog..." />
                        </SelectTrigger>
                        <SelectContent>
                          {catalog.map(cat => (
                            <SelectItem key={cat.id} value={cat.id}>{cat.name} (${cat.unitPrice})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input 
                        placeholder="Item description" 
                        value={item.description}
                        onChange={(e) => updateLineItem(item.id, 'description', e.target.value)}
                      />
                    </div>
                    <div className="w-20">
                      <Input 
                        type="number" 
                        placeholder="Qty" 
                        value={item.quantity}
                        onChange={(e) => updateLineItem(item.id, 'quantity', parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="w-32">
                      <Input 
                        type="number" 
                        placeholder="Price" 
                        value={item.unitPrice}
                        onChange={(e) => updateLineItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div className="w-24 text-right pt-2 font-bold">
                      ${(item.quantity * item.unitPrice).toLocaleString()}
                    </div>
                    <Button variant="ghost" size="icon" className="text-destructive mt-1" onClick={() => removeLineItem(item.id)}>
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" onClick={addLineItem} className="w-full dashed">
                <Plus size={14} className="mr-2" /> Add Line Item
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="bg-primary/5">
              <CardTitle className="text-lg">AI Assistant</CardTitle>
              <CardDescription>Optimize your invoice terms</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              <div className="space-y-2">
                <Label>Payment Terms</Label>
                <Textarea 
                  placeholder="e.g. Net 30, Due on receipt" 
                  value={paymentTerms}
                  onChange={(e) => setPaymentTerms(e.target.value)}
                />
              </div>
              <Button 
                variant="secondary" 
                className="w-full text-accent" 
                onClick={handleAiSuggestTerms}
                disabled={isAiLoading || !selectedClientId}
              >
                {isAiLoading ? <Loader2 className="animate-spin mr-2" /> : <Sparkles className="mr-2 h-4 w-4" />}
                Suggest Best Terms
              </Button>

              {aiSuggestions && (
                <div className="mt-4 p-3 bg-accent/10 rounded-lg border border-accent/20 space-y-2 animate-in fade-in zoom-in-95">
                  <p className="text-xs font-bold text-accent uppercase tracking-wider">AI Recommendations</p>
                  <div className="flex flex-wrap gap-2">
                    {aiSuggestions.terms.map(term => (
                      <Button 
                        key={term} 
                        variant="outline" 
                        size="sm" 
                        className="h-7 text-xs border-accent/30 hover:bg-accent/20"
                        onClick={() => setPaymentTerms(term)}
                      >
                        {term}
                      </Button>
                    ))}
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-tight italic">
                    "{aiSuggestions.reasoning}"
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>${totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tax (0%)</span>
                <span>$0.00</span>
              </div>
              <div className="border-t pt-4 flex justify-between font-bold text-xl">
                <span>Total</span>
                <span className="text-primary">${totalAmount.toLocaleString()}</span>
              </div>
              <div className="pt-4 space-y-2">
                <Label>Internal Notes</Label>
                <Textarea 
                  placeholder="Additional notes for client..." 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}