"use client"

import { useState } from "react"
import { useBillStreamData } from "@/hooks/use-billstream-data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Plus, Search, Trash2, Edit, Sparkles, Loader2 } from "lucide-react"
import { CatalogItem } from "@/lib/types"
import { generateItemDescription } from "@/ai/flows/generate-item-description"

export default function CatalogPage() {
  const { catalog, addCatalogItem, deleteCatalogItem, updateCatalogItem } = useBillStreamData()
  const [search, setSearch] = useState("")
  const [editingItem, setEditingItem] = useState<CatalogItem | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [itemNameForAi, setItemNameForAi] = useState("")
  const [generatedDesc, setGeneratedDesc] = useState("")

  const filteredCatalog = catalog.filter(i => 
    i.name.toLowerCase().includes(search.toLowerCase()) ||
    i.description.toLowerCase().includes(search.toLowerCase())
  )

  const handleSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const itemData: CatalogItem = {
      id: editingItem?.id || Math.random().toString(36).substr(2, 9),
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      unitPrice: parseFloat(formData.get("unitPrice") as string),
    }

    if (editingItem) {
      updateCatalogItem(editingItem.id, itemData)
    } else {
      addCatalogItem(itemData)
    }
    
    setIsDialogOpen(false)
    setEditingItem(null)
    setGeneratedDesc("")
  }

  const handleGenerateDescription = async () => {
    if (!itemNameForAi) return
    setIsGenerating(true)
    try {
      const result = await generateItemDescription({ briefDescription: itemNameForAi })
      setGeneratedDesc(result.detailedDescription)
    } catch (e) {
      console.error(e)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Service Catalog</h1>
          <p className="text-muted-foreground mt-1">Pre-define your services for lightning-fast invoicing.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open)
          if (!open) {
            setEditingItem(null)
            setGeneratedDesc("")
          }
        }}>
          <DialogTrigger asChild>
            <Button className="bg-accent hover:bg-accent/90">
              <Plus className="mr-2 h-4 w-4" /> Add Service
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{editingItem ? "Edit Service" : "Add New Service"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSave} className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Service/Item Name</Label>
                <div className="flex gap-2">
                  <Input 
                    id="name" 
                    name="name" 
                    defaultValue={editingItem?.name} 
                    onChange={(e) => setItemNameForAi(e.target.value)}
                    required 
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="icon" 
                    title="Generate professional description"
                    onClick={handleGenerateDescription}
                    disabled={isGenerating || (!itemNameForAi && !editingItem?.name)}
                  >
                    {isGenerating ? <Loader2 className="animate-spin" /> : <Sparkles className="text-accent" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Detailed Description</Label>
                <Textarea 
                  id="description" 
                  name="description" 
                  rows={4}
                  defaultValue={generatedDesc || editingItem?.description} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unitPrice">Unit Price ($)</Label>
                <Input id="unitPrice" name="unitPrice" type="number" step="0.01" defaultValue={editingItem?.unitPrice} required />
              </div>
              <DialogFooter>
                <Button type="submit" className="w-full bg-primary text-primary-foreground">
                  {editingItem ? "Update Item" : "Save Item"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input 
          placeholder="Search catalog by name or description..." 
          className="pl-10"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="bg-card rounded-xl border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[200px]">Service Name</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="w-[120px] text-right">Price</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCatalog.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                  No catalog items found.
                </TableCell>
              </TableRow>
            ) : (
              filteredCatalog.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>
                    <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
                  </TableCell>
                  <TableCell className="text-right font-bold">${item.unitPrice.toLocaleString()}</TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => {
                        setEditingItem(item)
                        setIsDialogOpen(true)
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive"
                      onClick={() => deleteCatalogItem(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}