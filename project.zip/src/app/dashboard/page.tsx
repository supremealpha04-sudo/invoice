"use client"

import { useBillStreamData } from "@/hooks/use-billstream-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Users, Clock, CheckCircle2, Package } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardPage() {
  const { invoices, clients } = useBillStreamData()

  const totalRevenue = invoices
    .filter((inv) => inv.status === 'paid')
    .reduce((sum, inv) => sum + inv.total, 0)
  
  const pendingAmount = invoices
    .filter((inv) => inv.status === 'sent')
    .reduce((sum, inv) => sum + inv.total, 0)

  const activeInvoices = invoices.filter((inv) => inv.status !== 'paid').length

  const stats = [
    {
      title: "Total Revenue",
      value: `$${totalRevenue.toLocaleString()}`,
      description: "Paid invoices",
      icon: CheckCircle2,
      color: "text-green-600",
    },
    {
      title: "Pending Amount",
      value: `$${pendingAmount.toLocaleString()}`,
      description: "Sent but unpaid",
      icon: Clock,
      color: "text-amber-600",
    },
    {
      title: "Active Invoices",
      value: activeInvoices.toString(),
      description: "Drafts and sent",
      icon: FileText,
      color: "text-primary",
    },
    {
      title: "Clients",
      value: clients.length.toString(),
      description: "Total registered",
      icon: Users,
      color: "text-accent",
    },
  ]

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome to BillStream</h1>
          <p className="text-muted-foreground mt-1">Here is what's happening with your business today.</p>
        </div>
        <Button asChild className="bg-accent hover:bg-accent/90">
          <Link href="/invoices/new">New Invoice</Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            {invoices.length === 0 ? (
              <p className="text-sm text-muted-foreground">No invoices generated yet.</p>
            ) : (
              <div className="space-y-4">
                {invoices.slice(-5).reverse().map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                    <div>
                      <p className="font-medium">{invoice.invoiceNumber}</p>
                      <p className="text-xs text-muted-foreground">
                        {clients.find(c => c.id === invoice.clientId)?.name || 'Unknown Client'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${invoice.total.toLocaleString()}</p>
                      <p className={`text-[10px] uppercase font-bold ${
                        invoice.status === 'paid' ? 'text-green-600' : 
                        invoice.status === 'sent' ? 'text-amber-600' : 'text-muted-foreground'
                      }`}>
                        {invoice.status}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <Button variant="link" asChild className="mt-4 p-0">
              <Link href="/invoices">View all invoices</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="h-24 flex-col gap-2" asChild>
              <Link href="/clients">
                <Users size={24} />
                Add Client
              </Link>
            </Button>
            <Button variant="outline" className="h-24 flex-col gap-2" asChild>
              <Link href="/catalog">
                <Package size={24} />
                Browse Catalog
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
