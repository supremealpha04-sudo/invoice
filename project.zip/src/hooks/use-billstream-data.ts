"use client"

import { useState, useEffect } from 'react';
import { Client, CatalogItem, Invoice } from '@/lib/types';

const STORAGE_KEY = 'billstream_v1_data';

type BillStreamData = {
  clients: Client[];
  catalog: CatalogItem[];
  invoices: Invoice[];
};

export function useBillStreamData() {
  const [data, setData] = useState<BillStreamData>({
    clients: [],
    catalog: [],
    invoices: [],
  });

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setData(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse saved data", e);
      }
    }
  }, []);

  const saveData = (newData: BillStreamData) => {
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
  };

  const addClient = (client: Client) => {
    saveData({ ...data, clients: [...data.clients, client] });
  };

  const updateClient = (id: string, updatedClient: Client) => {
    saveData({
      ...data,
      clients: data.clients.map((c) => (c.id === id ? updatedClient : c)),
    });
  };

  const deleteClient = (id: string) => {
    saveData({
      ...data,
      clients: data.clients.filter((c) => c.id !== id),
    });
  };

  const addCatalogItem = (item: CatalogItem) => {
    saveData({ ...data, catalog: [...data.catalog, item] });
  };

  const updateCatalogItem = (id: string, updatedItem: CatalogItem) => {
    saveData({
      ...data,
      catalog: data.catalog.map((i) => (i.id === id ? updatedItem : i)),
    });
  };

  const deleteCatalogItem = (id: string) => {
    saveData({
      ...data,
      catalog: data.catalog.filter((i) => i.id !== id),
    });
  };

  const saveInvoice = (invoice: Invoice) => {
    const exists = data.invoices.find((i) => i.id === invoice.id);
    if (exists) {
      saveData({
        ...data,
        invoices: data.invoices.map((i) => (i.id === invoice.id ? invoice : i)),
      });
    } else {
      saveData({ ...data, invoices: [...data.invoices, invoice] });
    }
  };

  const deleteInvoice = (id: string) => {
    saveData({
      ...data,
      invoices: data.invoices.filter((i) => i.id !== id),
    });
  };

  return {
    ...data,
    addClient,
    updateClient,
    deleteClient,
    addCatalogItem,
    updateCatalogItem,
    deleteCatalogItem,
    saveInvoice,
    deleteInvoice,
  };
}