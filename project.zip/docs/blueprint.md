# **App Name**: BillStream

## Core Features:

- Client Management: Allow users to add, view, edit, and store client contact and billing information for repeated use.
- Item/Service Catalog: Enable users to define and store frequently used items or services, including descriptions and unit prices, to streamline invoice creation.
- Invoice Creation & Editing: Provide a form-based interface for creating new invoices, selecting clients, adding catalog items or custom line items, calculating totals, and editing existing drafts.
- Invoice List & Detail View: Display a comprehensive list of all invoices with quick-view details (status, total amount, client name) and allow users to view full invoice details.
- Invoice PDF Generation: Generate a professional, downloadable PDF document of a finalized invoice, suitable for printing or sending to clients.
- AI-Powered Payment Term Suggester: An AI tool that suggests appropriate and professional payment terms (e.g., 'Net 30', 'Due on receipt') based on invoice value, client history, or standard business practices.
- User Authentication & Data Isolation: Secure login and user account management to ensure each user's invoices and client data are private and accessible only to them.

## Style Guidelines:

- Primary color: A sophisticated, muted blue (#2D6997) that conveys professionalism and trust, chosen to contrast effectively with a light background.
- Background color: A very light, desaturated grey-blue (#F2F5F8), providing a clean and calm canvas for document presentation and user interaction.
- Accent color: A vibrant cyan (#1ACCCD), analogous to the primary color but with a higher saturation and brightness, used for highlights and interactive elements.
- Headline and body font: 'Inter' (sans-serif) for its modern, highly legible, and objective aesthetic, ensuring clarity in financial documents and forms.
- Use clean, minimalistic, and consistent line-art or outline icons that complement the professional and clear visual theme, aiding quick comprehension without distraction.
- Employ a structured, clear layout with ample white space to enhance readability and ensure user focus on key information within invoices and forms. Responsive design for all screen sizes is essential.
- Incorporate subtle, functional animations such as smooth transitions for form submissions, navigation changes, or data loading, to provide visual feedback and a polished user experience without being distracting.